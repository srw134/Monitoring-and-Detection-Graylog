#! /bin/bash

##############################################
########## Pluralsight Editing Only ##########
##############################################
# Setting environment variables
export HTTP_PROXY=http://tstark:pssecrocks@172.31.245.222:8888
export HTTPS_PROXY=https://tstark:pssecrocks@172.31.245.222:8888

# Exporting the Lab Title for tmux.conf to use. MAKE SURE TO CHANGE THIS!
echo "export LABTITLE=\"PLURALSIGHT LABS\"" | sudo tee -a /etc/bash.bashrc

# tmux.conf one-liner for setting the style
echo "set-option -g status-style fg=colour15,bg=colour61; set-option -g status-left-length 100; set-option -g status-left \"\$LABTITLE \"; set-option -g status-right \"#H %H:%M %d-%b-%Y\"; set-option -g status-right-length 50; set-window-option -g window-status-current-format \"[#S #P:#{pane_current_command}]\"; set-window-option -g window-status-style fg=colour15,bg=colour61; set-window-option -g pane-border-style fg=black,bg=black; set-window-option -g pane-active-border-style fg=colour61,bg=colour61" | sudo tee -a /etc/tmux.conf

# Enable TMUX for every bash session
echo "if [ ! \$TMUX ]; then session=\$(tmux ls | grep \"pslab\"); if [ -z \"\$session\" ]; then tmux new -s pslab; else tmux a -t pslab; fi; fi" | sudo tee -a /etc/bash.bashrc

# timesyncd attempts to reach out to ntp.ubuntu.com but hangs because it gets not response, this will speed up overall loadtime.
systemctl stop systemd-timesyncd
systemctl disable systemd-timesyncd

# Test for valid proxy before running the rest of the code
echo "begin proxy test" >> /root/peaceinourtime
response=$(sudo http_proxy=$HTTP_PROXY curl --silent --write-out '%%{http_code}' --output /dev/null www.google.com)
echo $response >> /root/peaceinourtime
while [ $response -ne "200" ]; 
do    
    echo $response >> /root/peaceinourtime
    sleep 10
    response=$(sudo http_proxy=$HTTP_PROXY curl --silent --write-out '%%{http_code}' --output /dev/null www.google.com)
done

# Add succcessful proxy execution message to peaceinourtime log
echo "success1">> /psorceri/peaceinourtime

###############################################################################
########## CONTENT AUTHORING  Edit Application Setup Below This Line ########## 
###############################################################################

# Establishing App load tracking
mkdir /psorceri
echo "alias status='ls -ls /psorceri |cut -d \" \" -f 10,11,12,13,14'" >> /home/pslearner/.bashrc
touch "/psorceri/INITIALIZING"

# Example Usage for App Load Tracking
# touch "/psorceri/NMAP INITIALIZING"
# mv "/psorceri/NMAP INITIALIZING" "/psorceri/NMAP IN PROGRESS"

# Pull git repo for lab if your lab has lab files a repo will need to be created and the file uploaded under a "LAB_FILES"  folder to end up here:
# git -c http.proxy=$HTTP_PROXY clone https://github.com/ps-interactive/lab_apache-commons-text-enumeration-detection.git /home/pslearner/lab

#! SOME APPS need https proxy like so 'sudo https_proxy=$HTTPS_PROXY'
#########################################################################################################
# Install additionally required software packages
# Repo install - Ubuntu
# Example1 - sudo http_proxy=$HTTP_PROXY apt install -y apache2
# Example2 - Bypassing Acknowledgement Requirements - sudo http_proxy=$HTTP_PROXY DEBIAN_FRONTEND=noninteractive apt -y --force-yes install mysql-server
#
#########################################################################################################
# # Curl package and install from binary
# # Example - 
# sudo curl --proxy $HTTPS_PROXY https://raw.githubusercontent.com/rapid7/metasploit-omnibus/master/config/templates/metasploit-framework-wrappers/msfupdate.erb >> /home/pslearner/msfinstall 2>errors
# sudo chmod 755 /home/pslearner/msfinstall
# sudo http_proxy=$HTTP_PROXY /home/pslearner/msfinstall
#
##############################################
# # Use Docker or Docker Compose
# 
#   sudo mkdir -p /etc/systemd/system/docker.service.d
#   sudo touch /etc/systemd/system/docker.service.d/proxy.conf
#   echo "[Service]" | sudo tee -a /etc/systemd/system/docker.service.d/proxy.conf
#   echo "Environment=\"HTTP_PROXY=$HTTP_PROXY\"" | sudo tee -a /etc/systemd/system/docker.service.d/proxy.conf
#   echo "Environment=\"HTTPS_PROXY=$HTTP_PROXY\"" | sudo tee -a /etc/systemd/system/docker.service.d/proxy.conf
#   echo "Environment=\"NO_PROXY=localhost,127.0.0.1,::1\"" | sudo tee -a /etc/systemd/system/docker.service.d/proxy.conf
#   sudo systemctl daemon-reload
#   sudo systemctl restart docker

# # docker commands now work "docker pull" etc.
# sudo docker pull bkimminich/juice-shop

# # docker compose project from github
# COURSE_DIR_PATH=/home/pslearner/os-analysis-with-wazuh
# git -c http.proxy=$HTTP_PROXY clone https://github.com/ps-interactive/lab_os_anlaysis_wazuh.git $COURSE_DIR_PATH
# # Update permissions because user data script runs as root
# chown -R pslearner:pslearner $COURSE_DIR_PATH
# cd $COURSE_DIR_PATH
# sudo docker-compose up -d &

sudo http_proxy=$HTTP_PROXY apt update

sudo http_proxy=$HTTP_PROXY apt install -y apt-transport-https

#I believe the problem is this key isn't being imported.

sudo https_proxy=$HTTPS_PROXY wget -qO - https://artifacts.elastic.co/GPG-KEY-elasticsearch | sudo apt-key add - &> output.txt

sudo sh -c 'echo "deb https://artifacts.elastic.co/packages/8.x/apt stable main" | sudo tee -a /etc/apt/sources.list.d/elastic-8.x.list'

#sudo http_proxy=$HTTP_PROXY add-apt-repository ppa:oisf/suricata-stable

sudo http_proxy=$HTTP_PROXY apt update
#sudo http_proxy=$HTTP_PROXY apt upgrade -y

sudo http_proxy=$HTTP_PROXY apt-get install -y filebeat software-properties-common softflowd curl nmap python3-scapy


#Downloading rules from srw134 github - Much Quicker...
sudo https_proxy=$HTTPS_PROXY wget https://github.com/srw134/Network-Analysis-Session-Data-and-Signatures/raw/main/suricata-rules.zip

sudo https_proxy=$HTTPS_PROXY wget https://github.com/srw134/Network-Analysis-Session-Data-and-Signatures/raw/main/suricata.yaml

sudo https_proxy=$HTTPS_PROXY wget https://github.com/srw134/Network-Analysis-Session-Data-and-Signatures/raw/main/file.exe

sudo mkdir /var/lib/suricata
sudo mkdir /var/lib/suricata/rules
sudo unzip suricata-rules.zip -d /var/lib/suricata/rules/

#sudo ifconfig lo:1 10.10.10.1 netmask 255.255.255.0 up


#Launch web server

sudo nohup python3 -m http.server 8000 &


##Disable outbound DNS and ntp

sudo ufw default allow incoming
sudo ufw default allow outgoing
sudo ufw deny out to any port 123
sudo ufw deny out to any port 53
sudo ufw enable


#Configure Suricata

sudo mv /etc/suricata/suricata.yaml /etc/suricata/suricata.yaml.old
sudo cp suricata.yaml /etc/suricata/suricata.yaml

sudo systemctl restart suricata
sudo systemctl enable suricata

#Configure Filebeat

sudo rm /etc/filebeat/filebeat.yml

printf -- "filebeat.inputs:\n" >> filebeat.txt
  printf -- "  paths:\n" >> filebeat.txt
printf -- "\n" >> filebeat.txt
printf -- "filebeat.modules:\n" >> filebeat.txt
  printf -- "- module: suricata\n" >> filebeat.txt
  printf -- "  eve:\n" >> filebeat.txt
    printf -- "    enabled: true\n" >> filebeat.txt
    printf -- "    var.paths: [\"/var/log/suricata/eve.json\"]\n" >> filebeat.txt
#printf -- "\n" >> filebeat.txt
#printf -- "filebeat.config.modules:\n" >> filebeat.txt
#printf -- "  path: \$\{path.config\}/modules.d/*.yml\n" >> filebeat.txt
#  printf -- "  reload.enabled: false\n" >> filebeat.txt
#printf -- "\n" >> filebeat.txt
printf -- "setup.template.settings:\n" >> filebeat.txt
  printf -- "  index.number_of_shards: 1\n" >> filebeat.txt
printf -- "\n" >> filebeat.txt
#printf -- "setup.kibana:\n" >> filebeat.txt
#printf -- "\n" >> filebeat.txt
printf -- "output.logstash:\n" >> filebeat.txt
  printf -- "  hosts: [\"172.31.140.20:5044\"]\n" >> filebeat.txt
#printf -- "\n" >> filebeat.txt
#printf -- "processors:\n" >> filebeat.txt
#  printf -- "  - add_host_metadata:\n" >> filebeat.txt
#  printf -- "      when.not.contains.tags: forwarded\n" >> filebeat.txt
#  printf -- "  - add_cloud_metadata: ~\n" >> filebeat.txt
#  printf -- "  - add_docker_metadata: ~\n" >> filebeat.txt
#  printf -- "  - add_kubernetes_metadata: ~\n" >> filebeat.txt

sudo sed -i 's/\\\(.\)/\1/g' filebeat.txt

sudo cp filebeat.txt /etc/filebeat/filebeat.yml

sudo systemctl enable filebeat
sudo systemctl start filebeat

##Make sure these are getting to the collector.

sudo softflowd -i ens5 -n 172.31.140.20:9995 -d &




##############################################
########## END CONTENT AUTHORING #############
##############################################

##############################################
########## Pluralsight Editing Only ##########
##############################################
ip route add 169.254.0.0/16 via 127.0.0.1

# Remove files with reference to proxy
sudo rm -f /var/log/syslog
sudo rm -f /var/log/auth.log
sudo rm -f /var/log/cloud-init.log
sudo rm -f /var/log/cloud-init-output.log
sudo rm -f /var/lib/cloud/instance/obj.pkl
sudo rm -f /var/lib/cloud/instances/*/user-data.txt*
sudo rm -f /var/lib/cloud/instances/*/scripts/*
sudo rm -f /var/lib/cloud/instances/*/obj.pkl
sudo rm -f /var/lib/cloud/instances/*/user-data.txt*
sudo journalctl --rotate
sudo journalctl --vacuum-time=1s
sudo rm -f /etc/systemd/system/docker.service.d/proxy.conf

# Cleaning up enironment variables
unset HTTP_PROXY
unset HTTPS_PROXY

rm "/psorceri/INITIALIZING"
touch "/psorceri/SYSTEM COMPLETE"

# End message for PS DO NOT EDIT
echo "Happy Hunting">> /home/pslearner/peaceinourtime
