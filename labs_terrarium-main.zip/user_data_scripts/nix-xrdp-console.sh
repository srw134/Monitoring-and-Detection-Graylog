#! /bin/bash

##############################################
########## Pluralsight Editing Only ##########
##############################################
# Setting environment variables
export HTTP_PROXY=http://tstark:pssecrocks@172.31.245.222:8888
export HTTPS_PROXY=https://tstark:pssecrocks@172.31.245.222:8888

# Exporting the Lab Title for tmux.conf to use.
echo "export LABTITLE=\"PLURALSIGHT LABS\"" | sudo tee -a /etc/bash.bashrc

# tmux.conf one-liner for setting the style
echo "set-option -g status-style fg=colour15,bg=colour61; set-option -g status-left-length 100; set-option -g status-left \"\$LABTITLE \"; set-option -g status-right \"#H %H:%M %d-%b-%Y\"; set-option -g status-right-length 50; set-window-option -g window-status-current-format \"[#S #P:#{pane_current_command}]\"; set-window-option -g window-status-style fg=colour15,bg=colour61; set-window-option -g pane-border-style fg=black,bg=black; set-window-option -g pane-active-border-style fg=colour61,bg=colour61" | sudo tee -a /etc/tmux.conf

# Enable TMUX for every bash session
# NOTE: If you configure this setting for U20D, it will interfere with using tabs in terminal. Every tabbed session will open up the last session of TMUX. So, it's most helpful for U18C disconnects.
# echo "if [ ! \$TMUX ]; then session=\$(tmux ls | grep \"pslab\"); if [ -z \"\$session\" ]; then tmux new -s pslab; else tmux a -t pslab; fi; fi" | sudo tee -a /etc/bash.bashrc

# waits for proxy to be up and logs to script.test
sudo echo 'pslearner ALL=(ALL) NOPASSWD: ALL' >> /etc/sudoers
sudo echo 'export DISPLAY=:10' >> /home/pslearner/.bashrc
sudo chown root /usr/bin/dumpcap
sudo chmod u+s /usr/bin/dumpcap
# standard proxy ready check before attempts to install #####################################################################################################
echo "begin proxy test" >> /root/peaceinourtime
response=$(sudo http_proxy=$HTTP_PROXY curl --silent --write-out '%%{http_code}' --output /dev/null www.google.com)
echo $response >> /root/peaceinourtime
while [ $response -ne "200" ]; 
do    
    echo $response >> /root/peaceinourtime
    sleep 10
    response=$(sudo http_proxy=$HTTP_PROXY curl --silent --write-out '%%{http_code}' --output /dev/null www.google.com)
done
############################################################################################################################################################

echo "success1">> /root/peaceinourtime

###############################################################################
########## CONTENT AUTHORING  Edit Application Setup Below This Line ########## 
###############################################################################

# Establishing App load tracking
mkdir /psorceri
echo "alias status='ls -ls /psorceri |cut -d \" \" -f 10,11,12,13,14'" >> /home/pslearner/.bashrc
touch "/psorceri/INITIALIZING"

# Example Usage for App Load Tracking
# touch "/psorceri/NMAP INITIALIZING"
# mv "/psorceri/NMAP INITIALIZING" "/psorceri/NMAP IN PROGRESS"

# Pull git repo for lab if your lab has lab files a repo will need to be created and the file uploaded under a "LAB_FILES"  folder to end up here:
# git -c http.proxy=$HTTP_PROXY clone https://github.com/ps-interactive/lab_apache-commons-text-enumeration-detection.git /home/pslearner/lab

#! SOME APPS need https proxy like so 'sudo https_proxy=$HTTPS_PROXY'
#########################################################################################################
# Install additionally required software packages
# Repo install - Ubuntu
# Example1 - sudo http_proxy=$HTTP_PROXY apt install -y apache2
# Example2 - Bypassing Acknowledgement Requirements - sudo http_proxy=$HTTP_PROXY DEBIAN_FRONTEND=noninteractive apt -y --force-yes install mysql-server
#
#########################################################################################################
# # Curl package and install from binary
# # Example - 
# sudo curl --proxy $HTTPS_PROXY https://raw.githubusercontent.com/rapid7/metasploit-omnibus/master/config/templates/metasploit-framework-wrappers/msfupdate.erb >> /home/pslearner/msfinstall 2>errors
# sudo chmod 755 /home/pslearner/msfinstall
# sudo http_proxy=$HTTP_PROXY /home/pslearner/msfinstall
#
##########################################################################################################
# # Use Docker or Docker Compose
# 
sudo mkdir -p /etc/systemd/system/docker.service.d
sudo touch /etc/systemd/system/docker.service.d/proxy.conf
echo "[Service]" | sudo tee -a /etc/systemd/system/docker.service.d/proxy.conf
echo "Environment=\"HTTP_PROXY=$HTTP_PROXY\"" | sudo tee -a /etc/systemd/system/docker.service.d/proxy.conf
echo "Environment=\"HTTPS_PROXY=$HTTP_PROXY\"" | sudo tee -a /etc/systemd/system/docker.service.d/proxy.conf
echo "Environment=\"NO_PROXY=localhost,127.0.0.1,::1\"" | sudo tee -a /etc/systemd/system/docker.service.d/proxy.conf
sudo systemctl daemon-reload
sudo systemctl restart docker

# # docker commands now work "docker pull" etc.
# sudo docker pull bkimminich/juice-shop

# # docker compose project from github
# COURSE_DIR_PATH=/home/pslearner/os-analysis-with-wazuh
# git -c http.proxy=$HTTP_PROXY clone https://github.com/ps-interactive/lab_os_anlaysis_wazuh.git $COURSE_DIR_PATH
# # Update permissions because user data script runs as root
# chown -R pslearner:pslearner $COURSE_DIR_PATH
# cd $COURSE_DIR_PATH
# sudo docker-compose up -d &

# # Uncomment the line below to start the Attack Application service found on http://localhost:28657
# sudo systemctl start attack-application.service

#sudo http_proxy=$HTTP_PROXY apt update

LOG_FILE="output.txt"

sudo http_proxy=$HTTP_PROXY apt install -y apt-transport-https &>> $LOG_FILE

sudo https_proxy=$HTTPS_PROXY wget -qO - https://artifacts.elastic.co/GPG-KEY-elasticsearch | sudo apt-key add - &>> $LOG_FILE

sudo sh -c 'echo "deb https://artifacts.elastic.co/packages/7.x/apt stable main" | sudo tee -a /etc/apt/sources.list.d/elastic-7.x.list' &>> $LOG_FILE

sudo https_proxy=$HTTPS_PROXY wget -qO graylog-repo.deb https://packages.graylog2.org/repo/packages/graylog-5.2-repository_latest.deb &>> $LOG_FILE
sudo dpkg -i graylog-repo.deb &>> $LOG_FILE

sudo http_proxy=$HTTP_PROXY apt update &>> $LOG_FILE
# sudo http_proxy=$HTTP_PROXY apt upgrade -y &>> $LOG_FILE

#sudo http_proxy=$HTTP_PROXY apt-get install -y openjdk-21-jdk elasticsearch=7.10.2 logstash=1:7.10.2-1 kibana=7.10.2 jq graylog-server=5.2.0-7 npm &>> $LOG_FILE

sudo http_proxy=$HTTP_PROXY apt-get install -y openjdk-21-jdk elasticsearch=7.10.2 jq graylog-server=5.2.0-7 &>> $LOG_FILE

sudo https_proxy=$HTTPS_PROXY wget -qO mongodb-org-server_7.0.11_amd64.deb https://repo.mongodb.org/apt/ubuntu/dists/jammy/mongodb-org/7.0/multiverse/binary-amd64/mongodb-org-server_7.0.11_amd64.deb &>> $LOG_FILE

sudo dpkg -i mongodb-org-server_7.0.11_amd64.deb &>> $LOG_FILE


#sudo https_proxy=$HTTPS_PROXY wget https://raw.githubusercontent.com/srw134/Monitoring-and-Detection-Elastic-Stack/main/zeek.conf &>> $LOG_FILE
#sudo https_proxy=$HTTPS_PROXY wget https://raw.githubusercontent.com/srw134/Monitoring-and-Detection-Elastic-Stack/main/filebeat.yml &>> $LOG_FILE
#sudo https_proxy=$HTTPS_PROXY wget https://raw.githubusercontent.com/srw134/Monitoring-and-Detection-Elastic-Stack/main/zeek.yml &>> $LOG_FILE
#sudo https_proxy=$HTTPS_PROXY wget https://raw.githubusercontent.com/srw134/Monitoring-and-Detection-Elastic-Stack/main/local.zeek &>> $LOG_FILE

#sudo https_proxy=$HTTPS_PROXY wget https://raw.githubusercontent.com/srw134/Monitoring-and-Detection-Graylog/main/zeek_import.zip &>> $LOG_FILE
#sudo https_proxy=$HTTPS_PROXY wget https://raw.githubusercontent.com/srw134/Monitoring-and-Detection-Graylog/main/import_script &>> $LOG_FILE
#sudo https_proxy=$HTTPS_PROXY wget https://raw.githubusercontent.com/srw134/Monitoring-and-Detection-Graylog/main/timestamp &>> $LOG_FILE
sudo https_proxy=$HTTPS_PROXY wget https://raw.githubusercontent.com/srw134/Monitoring-and-Detection-Graylog/main/server.conf &>> $LOG_FILE
sudo https_proxy=$HTTPS_PROXY wget https://raw.githubusercontent.com/srw134/Monitoring-and-Detection-Graylog/main/touchready &>> $LOG_FILE


#mv /etc/elasticsearch/elasticsearch.yml /etc/elasticsearch/elasticsearch.yml.bak &>> $LOG_FILE
#cp /elasticsearch.yml /etc/elasticsearch/elasticsearch.yml &>> $LOG_FILE

sudo systemctl restart elasticsearch &>> $LOG_FILE
sudo systemctl enable elasticsearch &>> $LOG_FILE

#cp /zeek.conf /etc/logstash/conf.d/ &>> $LOG_FILE

#sudo systemctl restart logstash &>> $LOG_FILE
#sudo systemctl enable logstash &>> $LOG_FILE

#sudo systemctl restart kibana &>> $LOG_FILE
#sudo systemctl enable kibana &>> $LOG_FILE

sudo systemctl start mongod.service &>> $LOG_FILE
sudo systemctl enable mongod.service &>> $LOG_FILE

sudo cp /server.conf /etc/graylog/server/ &>> $LOG_FILE

sudo systemctl start graylog-server.service &>> $LOG_FILE
sudo systemctl enable graylog-server.service &>> $LOG_FILE

## Graylog Up?
#response=$(sudo curl -o /dev/null -s -w "%%{http_code}" -X GET http://127.0.0.1:9000/api/ &>> $LOG_FILE)

# Wait until the Graylog API is ready
#while [ "$response" -ne "200" ];
#do
#    sleep 10
#    response=$(sudo curl -o /dev/null -s -w "%%{http_code}" -X GET http://127.0.0.1:9000/api/ &>> $LOG_FILE)
#done

sudo https_proxy=$HTTPS_PROXY wget https://raw.githubusercontent.com/srw134/Monitoring-and-Detection-Graylog/main/output_data_file.json &>> $LOG_FILE
sudo https_proxy=$HTTPS_PROXY wget https://raw.githubusercontent.com/srw134/Monitoring-and-Detection-Graylog/main/output_mapping_file.json &>> $LOG_FILE

mkdir /home/pslearner/import &>> $LOG_FILE
sudo cp /output_* /home/pslearner/import/ &>> $LOG_FILE

#sudo mv output_* /home/pslearner/elasticsearch-dump/elasticsearch-dump-master/bin

#sudo chown -R pslearner:pslearner /home/pslearner/elasticsearch-dump

sudo docker pull elasticdump/elasticsearch-dump &>> $LOG_FILE

while RESPONSE=$(sudo curl -s -o /dev/null -w "%%{http_code}" -X DELETE "http://localhost:9200/graylog_0?pretty") && [ "$RESPONSE" -eq 404 ]; do sleep 2; echo "Response = 404" &>> $LOG_FILE; done




sudo docker run --rm -d --network="host" -v /home/pslearner/import/:/mnt/import elasticdump/elasticsearch-dump   --input=/mnt/import/output_mapping_file.json --output=http://localhost:9200/graylog_0 --type=mapping &>> $LOG_FILE

sudo docker run --rm -d --network="host" -v /home/pslearner/import/:/mnt/import elasticdump/elasticsearch-dump   --input=/mnt/import/output_data_file.json --output=http://localhost:9200/graylog_0 --type=data &>> $LOG_FILE

sudo curl -X PUT "localhost:9200/graylog_0/_settings" -H 'Content-Type: application/json' -d '{"index":{"number_of_replicas":0}}' &>> $LOG_FILE

sudo curl -s -o /dev/null -w "%{http_code}" -X PUT "localhost:9200/graylog_0/_settings" -H 'Content-Type: application/json' -d '{"index":{"number_of_replicas":0}}' | while read -r CODE; do [[ $CODE -ne 404 ]] && break; echo "Response: $CODE" >> $LOG_FILE; sleep 2; done


sudo chmod +x ./touchready &>> $LOG_FILE
sudo ./touchready &>> $LOG_FILE

##############################################
########## END CONTENT AUTHORING #############
##############################################

##############################################
########## Pluralsight Editing Only ##########
##############################################
ip route add 169.254.0.0/16 via 127.0.0.1

# Remove files with reference to proxy
sudo rm -f /var/log/syslog
sudo rm -f /var/log/auth.log
sudo rm -f /var/log/cloud-init.log
sudo rm -f /var/log/cloud-init-output.log
sudo rm -f /var/lib/cloud/instance/obj.pkl
sudo rm -f /var/lib/cloud/instances/*/user-data.txt*
sudo rm -f /var/lib/cloud/instances/*/scripts/*
sudo rm -f /var/lib/cloud/instances/*/obj.pkl
sudo rm -f /var/lib/cloud/instances/*/user-data.txt*
sudo journalctl --rotate
sudo journalctl --vacuum-time=1s
sudo rm -f /etc/systemd/system/docker.service.d/proxy.conf

# Cleaning up enironment variables
unset HTTP_PROXY
unset HTTPS_PROXY

rm "/psorceri/INITIALIZING"
touch "/psorceri/SYSTEM COMPLETE"

# End message for PS DO NOT EDIT
echo "Happy Hunting">> /home/pslearner/peaceinourtime
