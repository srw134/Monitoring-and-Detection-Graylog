#! /bin/bash

##############################################
########## Pluralsight Editing Only ##########
##############################################
# Setting environment variables
export http_proxy=http://tstark:pssecrocks@172.31.245.222:8888
export https_proxy=https://tstark:pssecrocks@172.31.245.222:8888

# Exporting the Lab Title for tmux.conf to use. MAKE SURE TO CHANGE THIS!
echo "export LABTITLE=\"PLURALSIGHT LABS\"" | sudo tee -a /etc/bash.bashrc

# tmux.conf one-liner for setting the style
echo "set-option -g status-style fg=colour15,bg=colour61; set-option -g status-left-length 100; set-option -g status-left \"\$LABTITLE \"; set-option -g status-right \"#H %H:%M %d-%b-%Y\"; set-option -g status-right-length 50; set-window-option -g window-status-current-format \"[#S #P:#{pane_current_command}]\"; set-window-option -g window-status-style fg=colour15,bg=colour61; set-window-option -g pane-border-style fg=black,bg=black; set-window-option -g pane-active-border-style fg=colour61,bg=colour61" | sudo tee -a /etc/tmux.conf

# Enable TMUX for every bash session
echo "if [ ! \$TMUX ]; then session=\$(tmux ls | grep \"pslab\"); if [ -z \"\$session\" ]; then tmux new -s pslab; else tmux a -t pslab; fi; fi" | sudo tee -a /etc/bash.bashrc

#timesyncd attempts to reach out to ntp.ubuntu.com but hangs because it gets not response, this will speed up overall loadtime.
systemctl stop systemd-timesyncd
systemctl disable systemd-timesyncd


# Test for valid proxy before running the rest of the code
echo "begin proxy test" >> /root/peaceinourtime
response=$(sudo http_proxy=$http_proxy curl --silent --write-out '%%{http_code}' --output /dev/null www.google.com)
echo $response >> /root/peaceinourtime
while [ $response -ne "200" ]; 
do    
    echo $response >> /root/peaceinourtime
    sleep 10
    response=$(sudo http_proxy=$http_proxy curl --silent --write-out '%%{http_code}' --output /dev/null www.google.com)
done

# Add succcessful proxy execution message to peaceinourtime log
echo "success1">> /psorceri/peaceinourtime

###############################################################################
########## CONTENT AUTHORING  Edit Application Setup Below This Line ########## 
###############################################################################

# Establishing App load tracking
mkdir /psorceri
echo "alias status='ls -ls /psorceri |cut -d \" \" -f 10,11,12,13,14'" >> /home/ec2-user/.bashrc
touch "/psorceri/INITIALIZING"

# Example Usage for App Load Tracking
# touch "/psorceri/NMAP INITIALIZING"
# mv "/psorceri/NMAP INITIALIZING" "/psorceri/NMAP IN PROGRESS"

#Pull git repo for lab if your lab has lab files a repo will need to be created and the file uploaded under a "LAB_FILES"  folder to end up here:
#sudo git -c http.proxy="$http_proxy" clone https://github.com/ps-interactive/labs_centos_enterprise_linux_storage.git /home/ec2-user/LAB_FILES

#! SOME APPS need https proxy like so 'sudo https_proxy=$https_proxy'
#########################################################################################################
# Install additionally required software packages
# Example 1 - sudo https_proxy=$https_proxy yum -y install git

#########################################################################################################
# # Curl package and install from binary
# # Example - 
# sudo curl --proxy $https_proxy https://raw.githubusercontent.com/rapid7/metasploit-omnibus/master/config/templates/metasploit-framework-wrappers/msfupdate.erb >> /home/pslearner/msfinstall 2>errors
# sudo chmod 755 /home/pslearner/msfinstall
# sudo http_proxy=$http_proxy /home/pslearner/msfinstall
#
##############################################
# # Use Docker or Docker Compose
# 
#   sudo mkdir -p /etc/systemd/system/docker.service.d
#   sudo touch /etc/systemd/system/docker.service.d/proxy.conf
#   echo "[Service]" | sudo tee -a /etc/systemd/system/docker.service.d/proxy.conf
#   echo "Environment=\"http_proxy=$http_proxy\"" | sudo tee -a /etc/systemd/system/docker.service.d/proxy.conf
#   echo "Environment=\"https_proxy=$http_proxy\"" | sudo tee -a /etc/systemd/system/docker.service.d/proxy.conf
#   echo "Environment=\"NO_PROXY=localhost,127.0.0.1,::1\"" | sudo tee -a /etc/systemd/system/docker.service.d/proxy.conf
#   sudo systemctl daemon-reload
#   sudo systemctl restart docker

# # docker commands now work "docker pull" etc.
# sudo docker pull bkimminich/juice-shop

# # docker compose project from github
# COURSE_DIR_PATH=/home/pslearner/os-analysis-with-wazuh
# git -c http.proxy=$HTTP_PROXY clone https://github.com/ps-interactive/lab_os_anlaysis_wazuh.git $COURSE_DIR_PATH
# # Update permissions because user data script runs as root
# chown -R pslearner:pslearner $COURSE_DIR_PATH
# cd $COURSE_DIR_PATH
# sudo docker compose up -d &

##############################################
########## END CONTENT AUTHORING #############
##############################################

##############################################
########## Pluralsight Editing Only ##########
##############################################
sudo rm -f /var/log/syslog
sudo rm -f /var/log/auth.log
sudo rm -f /var/log/messages 
sudo rm -f /var/log/dmesg
sudo rm -f /var/log/cloud-init.log
sudo rm -f /var/log/cloud-init-output.log
sudo rm -f /var/lib/cloud/instances/*/user-data.txt*
sudo rm -f /etc/systemd/system/docker.service.d/proxy.conf
sudo rm -f /var/lib/cloud/instance/obj.pkl
sudo rm -f /var/lib/cloud/instances/*/obj.pkl
sudo rm -f /var/lib/cloud/instance/scripts/*
sudo rm -f /var/lib/cloud/instances/*/scripts/*
sudo journalctl --rotate
sudo journalctl --vacuum-time=1s
sudo rm -rf /run/log/journal/*
sudo rm -f /etc/systemd/system/docker.service.d/proxy.conf

# Cleaning up enironment variables
unset http_proxy
unset https_proxy

rm "/psorceri/INITIALIZING"
touch "/psorceri/SYSTEM COMPLETE"


# End message for PS DO NOT EDIT
echo "Happy Hunting">> /home/ubuntu/peaceinourtime
