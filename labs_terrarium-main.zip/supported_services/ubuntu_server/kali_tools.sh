# Title: "Kali Tools Repository"
# Author: "ironcat"
# Date: "12-25-2021"
# Type: "Engineering"
# Description: "Adds the Kali repository" 

# We'll use this to add Kali repositories to the available apt repositories to enable installing Kali tools on the Ubuntu boxes. 

# Add valid key for Kali repos
wget 'https://archive.kali.org/archive-key.asc' -e use_proxy=on -e https_proxy=$HTTP_PROXY
sudo apt-key add archive-key.asc

# Add Kali repo to the sources.list and set as a secondary option (this prevents issues with packages from the default sources.list repos hanging on install)
echo 'deb http://http.kali.org/kali kali-rolling main non-free contrib' | sudo tee /etc/apt/sources.list.d/kali.list
echo -e '# Never prefer packages from the Kali repository\nPackage: *\nPin: release o=Kali\nPin-Priority: 1' | sudo tee /etc/apt/preferences.d/99kali

# Update apt to include Kali repos
sudo http_proxy=$HTTP_PROXY apt update -y && sudo http_proxy=$HTTP_PROXY apt upgrade -y

# After the Repository has been added, you can install any of the Kali tools.
# For a list of Kali tools, please visit https://www.kali.org/tools/
