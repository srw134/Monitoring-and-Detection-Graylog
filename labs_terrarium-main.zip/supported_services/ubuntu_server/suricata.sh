# Title: "Suricata"
# Author: "treyescairo"
# Date: "08-17-2023"
# Type: "Network IDS"
# Description: "Install Suricata"

# NOTE: Suricata is now installed by default on both U22C and U22D. This command is for starting the service in your user data scripts.
sudo suricata -c /etc/suricata/suricata.yaml -i ens5