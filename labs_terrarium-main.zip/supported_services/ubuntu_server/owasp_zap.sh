# Title: "OWASP Zap"
# Author: "treyescairo"
# Date: "09-28-2022"
# Type: "Penetration Testing"
# Description: "Install the latest version of OWASP Zap"

# NOTE: This is only meant for use on U20D, not U18C.

#PREREQUISITES
sudo http_proxy=$HTTP_PROXY apt update
sudo http_proxy=$HTTP_PROXY apt upgrade -y
sudo http_proxy=$HTTP_PROXY apt install -y openjdk-11-jdk

# Find and download the latest version of OWASP Zap
sudo curl --proxy $HTTP_PROXY -s https://api.github.com/repos/zaproxy/zaproxy/releases/latest | grep "browser_download_url.*deb" | cut -d : -f 2,3 | tr -d \" | sudo https_proxy=$HTTP_PROXY wget -i -

# Unzip the file and move it to its own directory
sudo find ./zaproxy*.deb -exec sudo dpkg -i '{}' +

# Then instruct the learner to navigate to Applications > Other > OWASP ZAP to access it.