# Title: "Postfix"
# Author: "vivicat"
# Date: "11-30-2022"
# Type: "Email"
# Description: "Install and start the Postfix Email Service"

sudo debconf-set-selections <<< "postfix postfix/mailname string globocat.com"
sudo debconf-set-selections <<< "postfix postfix/main_mailer_type string 'Internet Site'"
sudo http_proxy=$HTTP_PROXY apt install --assume-yes postfix
sudo systemctl start postfix