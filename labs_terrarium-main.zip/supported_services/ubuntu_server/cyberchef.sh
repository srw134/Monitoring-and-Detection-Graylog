# Title: "CyberChef"
# Author: "treyescairo"
# Date: "09-28-2022"
# Type: "Cyber Operations Platform"
# Description: "Install the latest version of CyberChef"

# NOTE: This is only meant for use on U20D, not U18C.

# Find and download the latest version of CyberChef
sudo curl --proxy $HTTP_PROXY -s https://api.github.com/repos/gchq/CyberChef/releases/latest | grep "browser_download_url.*zip" | cut -d : -f 2,3 | tr -d \" | sudo https_proxy=$HTTP_PROXY wget -i -

# Unzip the file and move it to its own directory
sudo find ./CyberChef*.zip -exec unzip -d ./CyberChef '{}' +

# Then instruct the learner to navigate to the HTML file and open it in locally in a browser.