# Title: "Damn Vulnerable Web Application"
# Author: "treyescairo"
# Date: "9-26-2022"
# Type: "Vulnerable Web Application"
# Description: "Install DVWA - a vulnerable web application"

##########################################################################################################
# A few things to note:
# The instance you're attaching this to needs to be set as a medium instance type, else you risk the application crashing.
# Make sure that the ingress/egress ports have been opened in the security group settings.
# Make sure you have assigned a private_ip address to the instance as well. This IP address will be used in any web browsing or scans you attempt.
# For more information about DWVA, visit: https://github.com/digininja/DVWA
# Credentials to log in are "admin:password".
##########################################################################################################

# This service expects that the forward proxy information got stored in the $HTTP_PROXY variable. Make sure your script has that or that you add those credentials in appropriately.

# Dependencies
sudo http_proxy=$HTTP_PROXY apt install -y apache2 mariadb-server mariadb-client php php-mysqli php-gd libapache2-mod-php

# DVWA Download and Install
sudo git -c http.proxy=$HTTP_PROXY clone https://github.com/digininja/DVWA.git
sudo cp ./DVWA/config/config.inc.php.dist ./DVWA/config/config.inc.php
sudo rm /var/www/html/index.html
sudo cp -r ./DVWA/* /var/www/html
sudo service apache2 start
sudo chown www-data /var/www/html/hackable/uploads
sudo chown www-data /var/www/html/config
sudo chown www-data /var/www/html/external/phpids/0.6/lib/IDS/tmp/phpids_log.txt
sudo sed -i 's/allow_url_include = Off/allow_url_include = On/' /etc/php/7.2/apache2/php.ini

# DVWA Database Creation
sudo mysql -e "create database dvwa"
sudo mysql -e "create user dvwa@localhost identified by 'p@ssw0rd'"
sudo mysql -e "grant all on dvwa.* to dvwa@localhost"
sudo mysql -e "flush privileges"
sudo apachectl restart

# NOTE: For some items to work properly, the learner may still have to finish the Setup / Reset DB by clicking on Create / Reset Database button on that page. But otherwise it's good to go!