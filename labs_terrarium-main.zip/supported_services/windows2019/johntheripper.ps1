<#
Title: "John the Ripper"
Author: "treyescairo"
Date: "09-28-2022"
Type: "Password Cracker"
Description: "Install version 1.9.0 of John the Ripper"
#>

<# Requires cred_init() #>
iwr -proxy $ProxyAddress -proxyCredential $proxy_credential -uri https://www.openwall.com/john/k/john-1.9.0-jumbo-1-win64.zip -outfile johntheripper.zip

<# Unzip the file and move it to its own directory #>
Expand-Archive -Path johntheripper.zip -DestinationPath C:\Users\pslearner\Desktop\

<#
GUI INSTALLATION (optional, may require above)
This just extracts the installer to the desktop. The learner will have to go through the installation themselves for use.
#>
iwr -proxy $ProxyAddress -proxyCredential $proxy_credential -uri https://openwall.info/wiki/_media/john/johnny/johnny_2.2_win.zip -outfile johnny.zip

Expand-Archive -Path johnny.zip -DestinationPath C:\Users\pslearner\Desktop\
