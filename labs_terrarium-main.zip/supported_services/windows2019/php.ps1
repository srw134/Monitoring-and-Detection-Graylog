<#
Title: "PHP"
Author: "ironcat"
Date: "12-25-2021"
Type: "Application"
Description: "Install PHP" 
#>

choco install php -y --proxy=$ProxyAddress --proxy-user=$ProxyUser --proxy-password=$ProxyPassword
