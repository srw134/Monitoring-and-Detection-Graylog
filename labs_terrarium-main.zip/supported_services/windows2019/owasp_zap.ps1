<#
Title: "OWASP Zap"
Author: "treyescairo"
Date: "09-28-2022"
Type: "Penetration Testing"
Description: "Install the latest version of OWASP Zap"
#>

<#
NOTE: If it can be helped, we highly suggest that you use OWASP ZAP on U20D instead of Windows.
The process takes less time and installation load on the learner in comparison to Linux.
#>

New-Item -Path 'C:\Users\Public\Desktop\LAB_FILES' -ItemType Directory

<# Requires cred_init() #>
app_status jdk11 "INITIALIZING"
iwr -proxy $HTTP_PROXY -proxyCredential $proxy_credential -uri https://github.com/adoptium/temurin11-binaries/releases/download/jdk-11.0.18%2B10/OpenJDK11U-jdk_x86-32_windows_hotspot_11.0.18_10.msi -outfile C:\Users\Public\Desktop\LAB_FILES\jdk11.exe
app_status jdk11 "DOWNLOADED"

<#
Find and download the latest version of OWASP ZAP
Requires cred_init()
#>
app_status owasp_zap "INITIALIZING"
$WebResponse = iwr -proxy $HTTP_PROXY -proxyCredential $proxy_credential -uri https://api.github.com/repos/zaproxy/zaproxy/releases/latest -UseBasicParsing
$iwrContent = ConvertFrom-Json $WebResponse.content
$zapURI = $iwrContent.assets.browser_download_url
iwr -proxy $HTTP_PROXY -proxyCredential $proxy_credential -uri $zapURI[6] -outfile C:\Users\Public\Desktop\LAB_FILES\zaproxy.exe
app_status owasp_zap "DOWNLOADED"

<# Then instruct the learner to navigate to the files and run the installers, first for JDK11 and then ZAP. #>