<#
Title: "PowerBI"
Author: "ironcat"
Date: "12-25-2021"
Type: "Application"
Description: "Install PowerBI" 
#>

<# Takes a while to load and to start but could be included in a "DATA" pre-build AMI #>

app_status PowerBI "IN PROGRESS"
choco install PowerBI -y --proxy=$ProxyAddress --proxy-user=$ProxyUser --proxy-password=$ProxyPassword --ignore-checksums
app_status PowerBI "DONE"